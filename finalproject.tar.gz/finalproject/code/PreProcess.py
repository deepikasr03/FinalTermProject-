import ExtractData
import TransformData
import LoadData


if __name__ == '__main__':
	extract = ExtractData.ExtractData()
	Transform = TransformData.TransformData()
	Load = LoadData.LoadData()